import "./styles.css";
import ParentCard from "./ParentCard";
import Clientcard from "./Componentinteraction/Clientcard";
import Servercard from "./Componentinteraction/Servercard";
import { useState } from "react";
export default function App() {
  let [fromclient, setFromclient] = useState();
  let [serverdata, setServerdata] = useState();
  let receivedata = (value) => {
    setFromclient(value);
  };
  let receivedataa = (value) => {
    setServerdata(value);
  };
  return (
    <div className="App">
      {/*<ParentCard />*/}

      <div>
        <Clientcard serverdata={serverdata} senddatatoapp={receivedata} />
      </div>
      <div>
        <Servercard fromclient={fromclient} senddatatoapp={receivedataa} />
      </div>
    </div>
  );
}
