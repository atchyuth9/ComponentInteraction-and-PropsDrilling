import React from "react";
import ComponentB from "./ComponentB";
let ComponentA = (props) => {
  return (
    <React.Fragment>
      <div className="card m-3">
        <div className="card-body bg-success text-white">
          <p className="h4">ComponentA</p>
          <small>{JSON.stringify(props.UserData)}</small>
          <ComponentB UserData={props.UserData} />
        </div>
      </div>
    </React.Fragment>
  );
};

export default ComponentA;
