import React from "react";
import ComponentC from "./ComponentC";
let ComponentB = (props) => {
  return (
    <React.Fragment>
      <div className="card m-3">
        <div className="card-body bg-info text-white">
          <p className="h4">ComponentB</p>
          <small>{JSON.stringify(props.UserData)}</small>
          <ComponentC UserData={props.UserData} />
        </div>
      </div>
    </React.Fragment>
  );
};

export default ComponentB;
