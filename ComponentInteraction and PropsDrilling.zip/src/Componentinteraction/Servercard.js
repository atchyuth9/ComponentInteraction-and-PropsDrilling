import React, { useState } from "react";
let Servercard = (props) => {
  let [servermsg, setServermsg] = useState();
  let senddataa = (e) => {
    e.preventDefault();
    props.senddatatoapp(servermsg);
  };
  return (
    <React.Fragment>
      <h3>Servercard</h3>
      <form onSubmit={senddataa}>
        <div>
          <input
            onChange={(e) => {
              setServermsg(e.target.value);
            }}
            type="text"
            value={servermsg}
            placeholder="enter server data"
          />
        </div>
        <br />
        <div>
          <input type="submit" value="submit" />
        </div>
        <div>
          <h3> from client:{props.fromclient}</h3>
        </div>
      </form>
    </React.Fragment>
  );
};
export default Servercard;
