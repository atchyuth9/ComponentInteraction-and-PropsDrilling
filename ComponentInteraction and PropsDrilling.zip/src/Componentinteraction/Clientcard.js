import React, { useState } from "react";
let Clientcard = (props) => {
  let [clientmsg, setClientmsg] = useState();
  let sendtoserver = (e) => {
    e.preventDefault();
    props.senddatatoapp(clientmsg);
  };
  return (
    <React.Fragment>
      <h3>clientcard</h3>
      <form onSubmit={sendtoserver}>
        <div>
          <input
            value={clientmsg}
            onChange={(e) => {
              setClientmsg(e.target.value);
            }}
            type="text"
            placeholder="enter server data"
          />
        </div>
        <br />
        <div>
          <input type="submit" value="submit" />
        </div>
        <div>
          <h3> from server: {props.serverdata}</h3>
        </div>
      </form>
    </React.Fragment>
  );
};
export default Clientcard;
