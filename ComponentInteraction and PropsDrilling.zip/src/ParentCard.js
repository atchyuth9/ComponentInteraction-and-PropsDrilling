import React, { useState } from "react";
import ChildCard from "./ChildCard";

let ParentCard = () => {
  let [parentInput, setparentInput] = useState();
  let [receive, setReceive] = useState();
  let receivedata = (e) => {
    setReceive(e);
  };
  return (
    <React.Fragment>
      <div>
        <h2> ParentComponent</h2>
        <pre> from child:{receive}</pre>
        <form>
          <input
            onChange={(e) => {
              setparentInput(e.target.value);
            }}
            value={parentInput}
            type="text"
            placeholder="enter the parent data"
          />
        </form>
      </div>
      <div>
        <ChildCard message={parentInput} sendchilddata={receivedata} />
      </div>
    </React.Fragment>
  );
};

export default ParentCard;
