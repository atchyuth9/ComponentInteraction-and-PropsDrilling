import React, { useState } from "react";

let ChildCard = (props) => {
  let [childInput, setchildinput] = useState();

  return (
    <React.Fragment>
      <div>
        <h3>childcomponent</h3>
        <pre>{childInput}</pre>
        <form>
          <input
            value={childInput}
            onChange={(e) => {
              setchildinput(e.target.value);
              props.sendchilddata(e.target.value);
            }}
            type="text"
            placeholder="enter child com data"
          />
        </form>
        <label>
          From parent: <h4>{props.message}</h4>
        </label>
      </div>
    </React.Fragment>
  );
};

export default ChildCard;
