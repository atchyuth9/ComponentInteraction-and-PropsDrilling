import React, { useState } from "react";
import ComponentA from "./Propsdrilling/ComponentA";
let App = (props) => {
  let [UserData, setuserData] = useState({
    Name: "Achyuth",
    Company: "Virtusa"
  });
  return (
    <React.Fragment>
      <div className="container mt-3">
        <div className="row">
          <div className="col">
            <div className="card">
              <div className="card-body bg-dark text-white">
                <p>AppCmponent</p>
                <small>{JSON.stringify(UserData)}</small>
                <ComponentA UserData={UserData} />
              </div>
            </div>
          </div>
        </div>
      </div>
    </React.Fragment>
  );
};

export default App;
